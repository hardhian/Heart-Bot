General use bot, has very little commands

/ping - replies to this with pong

/value - checks the value of the specified roblox item

/character [id] - looks up a roblox character by their id and displays when they joined and when they were last online

/play [url] - supposed to play youtube audio but is broken; currently looking into it.

/user - displays the discord user info
